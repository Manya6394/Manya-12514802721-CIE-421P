# Juputer Notebooks

This repository contains multiple programs written in jupyter notebook and google collab using python.

This is solely made with a purpose of storing and easily sharing/submitting my college work in field of Machine Learning.
